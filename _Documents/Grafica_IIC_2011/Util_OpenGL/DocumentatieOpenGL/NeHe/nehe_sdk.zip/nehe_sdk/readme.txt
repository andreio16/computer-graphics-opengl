NeHe SDK v1.10

This is a small Software Development Kit which covers a number of the
tutorials written by Jeff Molofee(NeHe) into a fairly unified framework
that should allow the construction of simple graphical games.

There are nine example executables(in the bin directory) showing off the 
capabilities of the SDK. They are:

Example 1: 	A simple rotating box and pyramid
Example 2: 	Text using OpenGL routines
Example 3: 	3d Text using OpenGL routines
Example 4: 	Rotating box and pyramid showing frame counter
Example 5: 	Particle engine and billboard demonstration
Example 6: 	Rotating cube using multitexturing
Example 7: 	MD2 animation and milkshape object rendering demo
Example 8: 	Video texturing
Example 9: 	Built in shapes and display list demonstration
Example 10:	Simple fog demonstration
Example 11:	Environment mapping demonstration
Example 12:	Scissor test and 2d demos

Required specification:

IBM compatible PC
Pentium 300 (although it may work with less) with 64MB RAM
OpenGL compatible graphics card with latest drivers.
Note: Some older cards, such as Voodoos and the early ATIs do not
 have drivers which appear to be completely compatible. Use these
 at your own risk. Any card problems reported are in bugs.txt
Microsoft Visual Studio 6 for recompilation and development, although
there should be no reason why it couldn't be compiled on Borland with 
a few changes. MinGW gcc however has no support for IPicture at the
time of writing, so porting it might be a little more complex.

License:

If you use this software you agree to be bound by the licence in
the license.txt file.

Known Bugs:

See bugs.txt

Acknowledgments:

See thanks.txt

Development with this SDK:

The simplest way to get to grips with this SDK is to read through the example files,
then throught the library header files.




